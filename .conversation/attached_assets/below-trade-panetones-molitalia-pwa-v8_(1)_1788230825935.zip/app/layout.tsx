import type { Metadata, Viewport } from "next";
import "./globals.css";
export const metadata: Metadata = { title:"Below Trade | Panetones Molitalia", description:"PWA de ventas, clientes y canjes para la campaña de Panetones Molitalia.", manifest:"/manifest.webmanifest", other:{"codex-preview":"development","mobile-web-app-capable":"yes","apple-mobile-web-app-capable":"yes"}, icons:{icon:"/favicon.svg",shortcut:"/favicon.svg",apple:"/pwa-icon.svg"} };
export const viewport: Viewport = { width:"device-width",initialScale:1,maximumScale:1,themeColor:"#000000" };
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="es"><body>{children}</body></html>}
