# Below Trade — Panetones Molitalia

MVP PWA mobile-first para iPhone, Android y escritorio.

## Funciones

- Panel Analista para usuarios, mercados, clientes y ventas.
- Mercado asignado por el Analista al promotor.
- Registro por unidades o planchas y validación del mix.
- Bonificación automática y evidencias fotográficas obligatorias.
- Estado offline, manifest y service worker PWA.

## Accesos demo

- Analista: `12345678` / `Below2026`
- Promotor: `87654321` / `Promo2026`

## Ejecutar

```bash
npm install
npm run dev
```

## Abrir con Docker Desktop en Windows

1. Descomprime el ZIP, por ejemplo en `C:\Apps\below-trade-panetones`.
2. Abre PowerShell dentro de esa carpeta.
3. Ejecuta:

```powershell
docker compose up -d --build
```

4. Abre en el navegador:

```text
http://localhost:3001
```

La aplicación usa el puerto `3001` de Windows para no interferir con otras aplicaciones. Para detener únicamente este aplicativo:

```powershell
docker compose down
```

Para volver a iniciarlo sin reconstruirlo:

```powershell
docker compose up -d
```

Para revisar sus mensajes de ejecución:

```powershell
docker compose logs -f
```

El MVP usa almacenamiento local para demostrar el flujo. Copia `.env.example` como `.env` y conecta PostgreSQL y la cuenta de servicio de Google Drive antes de producción. El ZIP no contiene secretos.
